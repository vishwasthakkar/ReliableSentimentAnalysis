import tweepy
consumer_key = "wJRGRDnAyiKQobBKiNBSdWCbl"
consumer_secret = "y4EplrVNbMN27Wl8kCCVMaLCKghtZCzBs10DwpJzlYmHlcepLY"
access_token = "2973557882-39g5RhcBl2scFt4u4Nwnczxw6kzC6yWalMoa9PH"
access_token_secret = "8IHj8PnChoy8DrYMOltE3qWZjcnbzRiJBmm2CGj0ao2bv"

# OAuth process, using the keys and tokens
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)
api = tweepy.API(auth)
trends1 = api.trends_available()

for i in [trend for trend in trends1[0]['trends']]:
    print i 
    print "####"
