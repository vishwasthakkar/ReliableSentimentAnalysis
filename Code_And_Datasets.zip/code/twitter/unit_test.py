from __future__ import unicode_literals
from __future__ import division

from models import Tweets

print Tweets.generate_fbsa_demo(Tweets())



"""
from textblob import TextBlob
# product_reviews = [
# """
# This one was good, best phone in terms of sound and camera with looks as well. Photo captured at night. The LCD broke down and no one is repairing the mobile. After going to service centre they are saying it will cost 5000 and why should I pay 5000 just for newly purchased phone. Please do not buy this G5sPlus model, the screen quality is very cheap.
# """,
# """
# Ordered it on 20th Oct and got on 23rd...I'm not impressed at all with the quality of packaging..no cardboard cover..but fortunately the phone is not damaged.. received it in perfect condition..now coming to the phone I really like its build quality..the screen is quite bright and viewing angles are good. Out of 64gb almost 52gb is free.. so u may not require micro SD card, however I m using another 32gb card..the fast charging is quite time saving,battery is slightly on lower side but for moderate users like me it will easily last for a day...u may need to charge it at 9pm..ram management is good..almost 2.3 GB is available.no lagging till now.. actually I'm not a gamer...I have not installed a single game..so can't comment about the gaming experience and heating issue..in normal usage no heating is experienced...there was some bugs in depth mode but I received camera update yesterday and definitely there is improvement in camera performance.. front camera is really good..I was #confused between mia1 and g5s plus...but I opted for this for better camera and fast charging facility.
# """,
# """
# I bought this phone based on the trust on Moto G versions I've been using for 3 years , but this one has disappointed me in all aspects. Crucial apps of Contacts, Messages and Phone does not work and hang all the time, most of the time you cannot access notifications, phone gets hot and battery drains super quick, turbocharger doesn't work sometimes, phone stays on same charge percentage for hours until you restart it. I don't know if Lenovo is trying to kill the product or it is like that only. I'd recommended Moto G3, Moto G4, Moto G5 and Moto G5Splus in last few years to many many people, but the latter two G5 and G5Splus people would curse me for their life.
# """,
# """
# The first one I bought shortly after the phone's release was very good. It was a made in China product. Recently, I bought it again but this time I got the made in India version. The problem is, it is inferior and defective. Games run slow, display is yellowish. I got it exchanged after a lot of hassle and convincing Amazon. Sadly, the new phone is also defective, same yellow display with slow running games and this time, it came with a dead pixel! I am tired of chasing after Amazon to exchange phones so I have decided to just keep it. Really disappointed in Amazon and the Moto brand. Should you decide to purchase this phone, I suggest you do so from a local store where you will be able to return the phone easily in case you get a defective product.
# """,
# """
# Reviewing after 1 MONTH HEAVY USAGE, Great mobile at this price range, Don't go with the negative reviews because of it's battery backup no one can expect more than one day backup at heavy usage with 3000mah battery, camera quality and depth mode is quite good but not extraordinary and the depth capture delay can be reduced with the latest update, display is a great con to the mobile, I believe no other mobile can beat this one's chipset and performance, it is splash proof too, no heating except while charging, Just go for it, I Moto... RATING: 4.5/5
# """,
# """
# Thanks for time to deliver Amazon .. good packing , delivery boy good service. Mobile awesome Moto G5s Plus quality camera amazing feature , battery life full day , design super ..
# """,
# """
# Ordered during the Great Indian Festival and received in 2 days with exchange at 12, 490..First impression after initial usage :
# 1. Form is excellent with metallic body and quite slim
# 2. Glossy finish and Lunar Grey look great
# 3. Charges very fast with the Turbo charger although the charging wire is less than a metre long.
# 4. Very responsive with no lags with 4 GB RAM and ample storage of 64 GB
# 5. Fingerprint sensor works fast and smooth.
#
# After 1 week of usage, many new features discovered like the night filter which reduces the blue light emission. This can be tweaked as required.
# Camera is excellent with dual 13 MP lenses as primary and 8 MP for wide angle selfies. Automatic adjustment is available for low light or night mode photos.
# Corning Gorilla glass gives very good protection.
# Overall, Moto G5s plus provides plenty of plusses and is great value for money.
# review imagereview image
# """,
# """
# What I liked ?
# --------------------
# Display is fantastic. Esp the night mode which cuts out blue light makes it so easy on the eyes. This may not be a ground breaking new feature but its there if you need it.
# Interface is neat & fast. Didn't notice any lags even when I opened multiple apps one after other without closing the previously opened ones. I know it usually starts to lag when your gallery is filled up with all sorts of media in it. But I think this phone will do just fine even then. CPU seems to be upto it.
# Google assistant works like a charm. Just speak up and have your wish granted.
# Sound quality through headphones (Audio Technica ATH M50) is good. Have heard better but I can easily settle for this phone.
# Charges fast enough and battery lasts long enough for my needs. I don't do any gaming.
# Size of phone and display resolution seems just about right. Not too big and not too small.
#
# What else I would like to have in this phone ?
# -------------------------------------------------------------------
# No notification LED. This is a bummer for me as I got so used to the multi color notification in the Samsung note series.
#
# No Compass. This means you don't get to see that torch like sign on your current location in google maps when you are still and trying to figure out if you are facing in the right direction to reach your destination. If you have compass on phone, the direction you face will be shown like a torch attached to the blue dot. This is very handy to have if you are in a unfamiliar foreign land and trying to walk to some place.However Google maps works just fine on all other areas on this phone.
# Also any apps which needs compass wont work.
#
# Overall for the price, the phone seems worth it.
# """,
# """
# Nice phone,camera is little bit disappointment.And if you compare iPhone 5s camera and audio sounds with this phone than I must honestly say that iPhone 5s wins over moto in both the aspects.Audio quality is good and loud but i was looking for decent audio with good base and beats.Hope that will help the buyers if they already own iPhone 5s,it clears the confusion about the camera and audio. Apart from that all is good. Fingerprint sensor is very responsive and fast.Camera shutter is a bit #slow but does the work quite nicely.Not facing any kind of lag while performing multitasking and playing high graphic games,although the device gets real hot while charging and the metal back makes it more hot but not to worry its because of the turbo charging i guess and depends on room temperature sometimes. So far I am not facing any problems with this phone but one thing I didn't like is we can't customize our apps in app drawr. Can't move app ikon in app drawer,can't make folders and #group a category of apps. But it is possible in homescreen but I wish I could move any app anywhere in app drawer. I don't know if its the phone or the nougat and the second thing i am worrying about is the service center. And yes the flashlight is quite good. Video recording is not upto the mark but it does the work capturing decent videos although a bit shaky due to lack of io.Anyways its a good phone, worth the money,feels a bit premium, but you know premium phones are something you can't #compare. Go for it !
# """,
# """
# I bought this phone based on the trust on Moto G versions I've been using for 3 years , but this one has disappointed me in all aspects
# Crucial apps of Contacts, Messages and Phone does not work and hang all the time, most of the time you cannot access notifications, phone gets hot and battery drains super quick, turbocharger doesn't work sometimes, phone stays on same charge percentage for hours until you restart it.
# I don't know if Lenovo is trying to kill the product or it is like that only.
# I'd recommended Moto G3, Moto G4, Moto G5 and Moto G5Splus in last few years to many many people, but the latter two G5 and G5Splus people would curse me for their life.
"""
]


import os
import pickle

module_dir = os.path.dirname(__file__)
#file_path = os.path.join(module_dir, 'static/datasets/imdb_labelled_utf_8.txt')
file_path = os.path.join(module_dir, 'static/datasets/amazon_cells_labelled.txt')

txt_data = open(file_path,"r").read()
txt_data = str(txt_data).decode('utf-8').encode('utf-8').lower()

features = {}
nouns_count = 0
for p in txt_data.split('\n')[0:999]:

    if(len(p.split('\t'))>1):
        i,j = p.split('\t')
        tb = TextBlob(str(i))
        tb.correct()
        for sent in tb.sentences:
            sentiment = sent.sentiment.polarity
            #print sentiment
            for noun in [tag for tag in sent.tags if str(tag[1])=="NN" or str(tag[1])=="NNP"]:
                if noun[0] not in features:
                    features[noun[0]] = [0,0,0]
                if sentiment>0:
                    features[noun[0]][0] += 1
                elif sentiment<0:
                    features[noun[0]][1] += 1
                else:
                    features[noun[0]][2] += 1
                nouns_count+=1
feature_set_final={}
for key in features:
    if [i for i in features[key] if i>=3]:
        print key,":",features[key]
        feature_set_final[key] = features[key]

file_path = os.path.join(module_dir, 'static/word_features_final.pickle')
save_features_set_final = open(file_path, "wb")
pickle.dump(feature_set_final, save_features_set_final)
save_features_set_final.close()

print "Nouns",nouns_count
"""
