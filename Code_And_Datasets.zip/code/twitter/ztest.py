type_x="imdb"
path = "static/pickled_algos/"+type_x+"/originalnaivebayes.pickle"
load_classifier = open(path, "rb")
print "hello"
